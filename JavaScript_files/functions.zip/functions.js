/* Addtodom weer een lege array
en dan weer nieuwe data hangen aan de Ul en li

button click, event
array.array.forEach(element => {
  result
});
 */
//console.log(xxxxxxxx);


/* const addListToDom = (array) => {
  //de Dom moet eerst weer leeg.
  document.querySelector("#main__list").innerHTML = "";
  array.forEach(element => {
    let List = document.createElement("ul");
    let ListItem = document.createElement("li");
    List.appendChild(regionListItem);
  });
};
 */
const getRegionData = () => {
  return [...new Set(randomPersonData.map(currentValue => currentValue = currentValue.region).sort())];
};
// event maken dat getregiondata aanroept. 
console.log(getRegionData());

const findCapricornWomen = () => {
  const capricornWomenList =
    randomPersonData.filter(currentValue => currentValue.gender === "female"
      && currentValue.age > 30
      && currentValue.birthday.dmy.split("/", 2)
        .filter(element => element >= 30 /* && || [0] <= 22 && [1] === 11) */));



  //&& randomPersonData.sort(name)
  return capricornWomenList;
};
console.log(findCapricornWomen());


/* const getOldCreditcards = () => {
  const oldCreditcardList =
    randomPersonData.map(currentValue => currentValue.credit_card
      .filter(currentValue.credit_card.expiration))
  return oldCreditcardList;
};

console.log(getOldCreditcards()); */
/*
movie.addEventListener("change", function (event) {
  handleOnChangeEvent(event);
})
 */

/* function handleOnChangeEvent(event) {
  switch (event.target.value) {
    case "nieuwste-films":
      filterLatestMovies();
      break;
    case "avengers":
      filterMovies("Avengers");
      break;
    case "x-men":
      filterMovies("X-Men");
      break;
    case "princess":
      filterMovies("Princess");
      break;
    case "batman":
      filterMovies("Batman");
      break;
    default:
  }
}; */

/* var persons = [
  {firstname : "Malcom", lastname: "Reynolds"},
  {firstname : "Kaylee", lastname: "Frye"},
  {firstname : "Jayne", lastname: "Cobb"}
];


function getFullName(item) {
  var fullname = [item.firstname,item.lastname].join(" ");
  return fullname;
} */